def sayHi():
    return "Hello"
