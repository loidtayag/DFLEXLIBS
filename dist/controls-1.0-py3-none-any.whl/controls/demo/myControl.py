def sayHi():
    return "Hello"
